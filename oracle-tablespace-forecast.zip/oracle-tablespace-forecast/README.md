# Oracle PDB Tablespace Forecast – Ansible + Python Flask

## Architecture

```
Ansible Controller
      │
      ▼
OEM Server (oracle user)
  ├─ oem_collect.py   ──► SYSMAN.MGMT$TABLESPACE_DAILY   (history)
  │                   ──► SYSMAN.MGMT$DB_DATAFILES         (datafiles)
  │                   ──► SYSMAN.MGMT$TABLESPACE_INFO       (current)
  │                        └── tablespace_raw.json
  │
  ├─ forecast.py      ──► Linear regression per tablespace
  │                        ├── tablespace_forecast.json
  │                        ├── sql/add_datafiles_3m.sql
  │                        ├── sql/add_datafiles_6m.sql
  │                        └── sql/add_datafiles_12m.sql
  │
  ├─ store_results.py ──► DBA_REPORTS.TS_FORECAST (Oracle table)
  │
  ├─ generate_report.py ► reports/tablespace_forecast_YYYY-MM-DD.html
  │                     ► reports/email_body.html
  │
  ├─ flask_api.py     ──► REST API (port 8080) + serves dashboard
  │       /api/forecast        GET – forecast data (JSON)
  │       /api/summary         GET – KPI counts per date
  │       /api/dates           GET – list of available report dates
  │       /api/sql/3|6|12      GET – SQL file download
  │       /api/health          GET – DB connectivity check
  │       /                    GET – web dashboard (index.html)
  │
  └─ send_email.py    ──► SMTP → DBA team (HTML + SQL attachments)
```

## Directory Structure

```
oracle-tablespace-forecast/
├── site.yml                            # Main playbook entry point
├── inventory/hosts.ini                 # OEM server inventory
├── vars/
│   ├── main.yml                        # All tunable parameters
│   └── vault.yml                       # Encrypted credentials
├── roles/
│   ├── oem_collect/tasks/main.yml
│   ├── forecast/tasks/main.yml
│   ├── report/tasks/main.yml           # Deploys Flask + dashboard
│   └── email/tasks/main.yml
├── templates/
│   ├── oem_collect.py.j2
│   ├── forecast.py.j2
│   ├── store_results.py.j2
│   ├── generate_report.py.j2
│   ├── flask_api.py.j2                 # Flask REST API (replaces PHP)
│   ├── ts_forecast_api.service.j2      # systemd unit for Flask
│   ├── send_email.py.j2
│   └── web_dashboard.html.j2           # Dashboard (calls Flask API)
└── files/
    ├── create_report_schema.sql         # DDL – reporting table + views
    └── requirements.txt                 # Python dependencies
```

## Prerequisites

### Python packages (on OEM / report server)
```bash
pip3 install -r files/requirements.txt
# or individually:
pip3 install cx_Oracle Flask jinja2 pandas numpy
```

### Oracle Instant Client
```bash
# RHEL/OEL 8:
dnf install oracle-instantclient-basiclite oracle-instantclient-devel

# Or download RPMs from Oracle and set:
export LD_LIBRARY_PATH=/usr/lib/oracle/21/client64/lib
```

### Oracle permissions
```sql
-- On OEM repository DB:
GRANT SELECT ON SYSMAN.MGMT$TABLESPACE_DAILY TO <oem_user>;
GRANT SELECT ON SYSMAN.MGMT$DB_DATAFILES     TO <oem_user>;
GRANT SELECT ON SYSMAN.MGMT$TABLESPACE_INFO  TO <oem_user>;

-- On reporting DB – run as SYSDBA:
-- @files/create_report_schema.sql
```

## Quick Start

### 1. Configure credentials
```bash
# Edit vars/vault.yml, then encrypt:
ansible-vault encrypt vars/vault.yml
echo "your_vault_password" > ~/.vault_pass && chmod 600 ~/.vault_pass
```

### 2. Configure parameters in vars/main.yml
```yaml
oem_host:          "your-oem-server"
oem_service:       "oemrep"
report_db_host:    "your-report-db"
report_db_service: "reportdb"
smtp_host:         "your-smtp-server"
smtp_to:           ["dba@company.com"]
web_report_url:    "http://oem-server:8080"
flask_port:        8080
```

### 3. Create the reporting schema
```bash
sqlplus sys/password@reportdb as sysdba @files/create_report_schema.sql
```

### 4. Run the playbook
```bash
ansible-playbook site.yml \
  -i inventory/hosts.ini \
  --vault-password-file ~/.vault_pass
```

### 5. Install daily cron (06:00 AM)
```bash
ansible-playbook playbooks/install_cron.yml \
  -i inventory/hosts.ini \
  --vault-password-file ~/.vault_pass
```

### 6. Access the dashboard
```
http://your-oem-server:8080/
```

## Flask API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Web dashboard |
| `/api/forecast` | GET | All tablespace forecast data |
| `/api/forecast?date=2026-05-20` | GET | Specific date |
| `/api/forecast?risk=CRITICAL` | GET | Filter by risk |
| `/api/forecast?search=USERS` | GET | Text search |
| `/api/summary` | GET | KPI counts per run date |
| `/api/dates` | GET | Available report dates |
| `/api/sql/3` | GET | Download 3-month SQL |
| `/api/sql/6` | GET | Download 6-month SQL |
| `/api/sql/12` | GET | Download 12-month SQL |
| `/api/health` | GET | DB connectivity check |

## Forecast Logic

Linear regression over last 90 days of OEM metric data:
```
slope (GB/day)  = OLS regression of used_space vs collection_date
projected_Nm    = current_used + slope × (N months × 30.44 days)
space_needed    = max(projected_Nm - current_total, 0)
```

## SQL Generation Rules

- Datafile max: **30 GB** | Initial size: **1 GB** AUTOEXTEND ON NEXT 512M MAXSIZE 30G
- ASM diskgroup auto-detected from `+DISKGROUP/…` path prefix
- Path increments trailing number: `ts01.dbf` → `ts02.dbf`
- Multiple statements generated when needed space > 30 GB

## Risk Levels

| Level | Condition |
|-------|-----------|
| CRITICAL | Current usage ≥ 90% |
| CRITICAL_FORECAST | Projected 3-month usage ≥ 90% |
| WARNING | Current usage ≥ 80% |
| WARNING_FORECAST | Projected 6-month usage ≥ 80% |
| OK | All forecasts healthy |
